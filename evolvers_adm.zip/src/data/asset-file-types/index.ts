// src/data/asset-file-types/index.ts

export { assetFileTypeApi, api } from "./api";
export { assetFileTypeRepository, repository } from "./repository";
