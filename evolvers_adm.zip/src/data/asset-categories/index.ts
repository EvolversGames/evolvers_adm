// src/data/asset-categories/index.ts

export { assetCategoryApi, api } from "./api";
export { assetCategoryRepository, repository } from "./repository";
