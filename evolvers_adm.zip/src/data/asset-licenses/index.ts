// src/data/asset-licenses/index.ts

export { assetLicenseApi, api } from "./api";
export { assetLicenseRepository, repository } from "./repository";
