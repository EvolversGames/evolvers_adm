// src/data/assets/index.ts

export { assetApi, api } from "./api";
export { assetStorage, storage } from "./storage";
export { assetRepository, repository } from "./repository";
