// src/domain/asset-licenses/index.ts

export * from "./assetLicense";
