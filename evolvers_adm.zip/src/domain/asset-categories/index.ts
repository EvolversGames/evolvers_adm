// src/domain/asset-categories/index.ts

export * from "./assetCategory";
