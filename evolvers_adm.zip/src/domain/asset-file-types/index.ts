// src/domain/asset-file-types/index.ts

export * from "./assetFileType";
